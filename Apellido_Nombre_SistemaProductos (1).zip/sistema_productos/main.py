from producto import Producto
from alimento import Alimento
from electronico import Electronico
from ropa import Ropa


# Crear los productos solicitados
leche = Alimento("Leche", 2000, 20, "15/11/2026")
notebook = Electronico("Notebook", 800000, 5, "12 meses")
cuaderno = Producto("Cuaderno", 5000, 30)

# Crear al menos dos prendas
remera = Ropa("Remera", 12000, 10, "M", "Remera")
pantalon = Ropa("Pantalón", 25000, 8, "42", "Pantalón")

# Una sola lista con todos los productos
productos = [leche, notebook, cuaderno, remera, pantalon]


# EJERCICIO 1: polimorfismo y precio final
print("\n========== PRECIOS FINALES ==========")
for producto in productos:
    print(f"{producto.nombre}: ${producto.calcular_precio_final():,.2f}")


# EJERCICIO 2: mostrar los datos de la ropa
print("\n========== DATOS DE LA ROPA ==========")
print(remera.mostrar_datos())
print(pantalon.mostrar_datos())
print("Talle de la remera:", remera.mostrar_talle())


# EJERCICIO 3: ventas y reposiciones
print("\n========== PRUEBAS DE STOCK ==========")

print("\nVenta válida:")
print("Stock antes:", leche.get_stock())
leche.vender(5)
print("Stock después:", leche.get_stock())

print("\nVenta con stock insuficiente:")
print("Stock antes:", notebook.get_stock())
notebook.vender(10)
print("Stock después:", notebook.get_stock())

print("\nReposición:")
print("Stock antes:", cuaderno.get_stock())
cuaderno.reponer(10)
print("Stock después:", cuaderno.get_stock())


# Mostrar todos los productos, sus tipos, stock y precio final
print("\n========== LISTADO COMPLETO ==========")
for producto in productos:
    print(
        f"Nombre: {producto.nombre} | "
        f"Tipo: {type(producto).__name__} | "
        f"Stock: {producto.get_stock()} | "
        f"Precio final: ${producto.calcular_precio_final():,.2f}"
    )


# Calcular el valor total del inventario
print("\n========== VALOR DEL INVENTARIO ==========")
total_inventario = 0

for producto in productos:
    valor_producto = producto.get_stock() * producto.calcular_precio_final()
    total_inventario += valor_producto
    print(
        f"{producto.nombre}: {producto.get_stock()} x "
        f"${producto.calcular_precio_final():,.2f} = ${valor_producto:,.2f}"
    )

print(f"Valor total del inventario: ${total_inventario:,.2f}")


# Encontrar el producto de mayor precio final sin usar max()
print("\n========== PRODUCTO DE MAYOR PRECIO ==========")
producto_mas_caro = productos[0]

for producto in productos:
    if producto.calcular_precio_final() > producto_mas_caro.calcular_precio_final():
        producto_mas_caro = producto

print(
    f"El producto más caro es {producto_mas_caro.nombre}, "
    f"con un precio final de ${producto_mas_caro.calcular_precio_final():,.2f}."
)


# RESPUESTAS PARA DEFENDER EL PROGRAMA
#
# 1. ¿Qué diferencia hay entre heredar un método y sobrescribirlo?
# Heredar es recibir un método de la clase padre y poder utilizarlo.
# Sobrescribir es definir nuevamente ese método en una clase hija,
# cambiando su comportamiento.
#
# 2. ¿Por qué el mismo for puede invocar calcular_precio_final()
#    en todos los productos sin usar if por tipo?
# Porque se utiliza el polimorfismo: cada objeto ejecuta la versión
# del método que corresponde a su propia clase.
#
# 3. ¿Qué inicializa super().__init__(...) en cada clase hija?
# Inicializa los atributos que las clases hijas heredan de Producto:
# nombre, precio y stock.
#
# 4. ¿Qué diferencia hay entre vender(5), reponer(5) y set_stock(5)?
# vender(5) descuenta cinco unidades si hay stock suficiente.
# reponer(5) agrega cinco unidades al stock.
# set_stock(5) establece directamente el stock en cinco unidades.
#
# 5. Identificá una línea que demuestre encapsulamiento,
#    herencia y polimorfismo.
# Encapsulamiento: self.__stock = stock, en producto.py.
# Herencia: class Alimento(Producto), en alimento.py.
# Polimorfismo: producto.calcular_precio_final(), en el for de main.py.
#
# 6. ¿Qué responsabilidad tiene main.py y por qué separamos
#    las clases en distintos archivos?
# main.py es el punto de entrada: crea los objetos, los guarda
# en una lista, prueba las operaciones y muestra los resultados.
# Separamos las clases para organizar el proyecto, facilitar su
# mantenimiento y separar las responsabilidades de cada archivo.
