from producto import Producto


class Ropa(Producto):
    def __init__(self, nombre, precio, stock, talle, categoria):
        super().__init__(nombre, precio, stock)
        self.talle = talle
        self.categoria = categoria

    def mostrar_talle(self):
        return self.talle

    def mostrar_datos(self):
        return (
            f"{super().mostrar_datos()} | Tipo: Ropa "
            f"| Talle: {self.talle} | Categoría: {self.categoria}"
        )

    def calcular_precio_final(self):
        return self.precio * 0.85  # Descuento del 15 %
